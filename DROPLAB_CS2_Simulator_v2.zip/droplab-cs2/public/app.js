(() => {
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const state={data:null,user:null,csrf:null,view:'home',caseId:null,profile:null,leaderboard:[],adminUsers:[],adminLogs:[],filter:'all',sort:'new',busy:false,latestDrop:null,feed:[],upgradeSource:null,upgradeTarget:null,upgradeMotion:'normal',upgradeRange:'all',upgradeSearch:''};
const fmt=n=>Number(n||0).toLocaleString('ru-RU');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=s=>typeof s==='string'&&(/^https:\/\//i.test(s)||/^\/assets\/covers\/[a-z-]+\.webp$/.test(s))?esc(s):'';
const skin=id=>state.data?.skins?.find(s=>s.id===id);
const rarity=id=>state.data?.rarities?.[id]||{color:'#90a6b6',name:'Предмет'};
const imageTag=(src,classname='item-image',fallback='weapon',alt='Скин CS2')=>`<img class="${classname}" src="${url(src)||'/assets/'+(fallback==='knife'?'knife':'weapon')+'.svg'}" alt="${esc(alt)}" loading="lazy"/>`;
const fallbackFor=s=>/knife|karambit|bayonet/i.test(s?.id||s?.name||'')?'knife':'weapon';
const skinArt=(s,cls)=>imageTag(s?.image,cls,fallbackFor(s),s?.name||'Скин CS2');
const getCase=id=>state.data?.cases?.find(c=>c.id===id);
const caseCover=c=>c.coverImage?imageTag(c.coverImage,'case-art case-crate-art','weapon',c.name):skinArt(skin('ak-neon'),'case-art');
async function api(path,method='GET',body=null){
 const opts={method,credentials:'same-origin',headers:{}};
 if(method!=='GET'){opts.headers['Content-Type']='application/json';if(state.csrf)opts.headers['x-csrf-token']=state.csrf;opts.body=JSON.stringify(body||{});}
 let r;try{r=await fetch(path,opts);}catch{throw new Error('Нет соединения с сервером');}
 let j;try{j=await r.json();}catch{throw new Error('Сервер вернул неверный ответ');}
 if(!r.ok)throw new Error(j.error||`Ошибка ${r.status}`);
 return j;
}
function toast(message,error=false){
 const root=$('#toast-root'),node=document.createElement('div');node.className='toast'+(error?' error':'');node.textContent=message;root.appendChild(node);setTimeout(()=>node.remove(),4400);
}
function renderAccount(){
 const user=state.user;
 $('#wallet-value').textContent=fmt(user?.balance||0);
 $('#header-username').textContent=user?.name||'Войти';
 $('#header-avatar').innerHTML=user?.avatar?`<img src="${url(user.avatar)}" alt="">`:esc((user?.name||'?')[0]?.toUpperCase());
 if(user){
  $('#side-account').innerHTML=`<div class="side-account-card"><span class="user-avatar">${user.avatar?`<img src="${url(user.avatar)}" alt="">`:esc(user.name[0])}</span><div class="side-account-info"><b title="${esc(user.name)}">${esc(user.name)}</b><small>${user.role==='admin'?'АДМИНИСТРАТОР':user.steamId?'STEAM ПОДКЛЮЧЁН':'ГОСТЕВОЙ АККАУНТ'}</small></div></div>`;
 }else $('#side-account').innerHTML='<div class="account-placeholder">Войди, чтобы сохранять<br>свои дропы и баланс</div>';
 $('#admin-nav').classList.toggle('hidden',user?.role!=='admin');
 const count=$('#case-count');if(count&&state.data)count.textContent=state.data.cases.length;
 const ready=!user||Date.now()-(user.lastBonus||0)>86400000;
 $('#bonus-box .bonus-btn').textContent=ready?'Забрать +200 CR ↗':'Бонус получен ✓';
 $('#bonus-box .bonus-btn').disabled=!!user&&!ready;
}
function demoFeed(){
 const names=['★ghost.67','blackmamba','s1mply_luck','donk.exe','aimlock','M1racle','peeka','vortex_gg','flickshot','not_a_bot','k1ng','smoke.mid','NAVI_fan','crybaby','frost','eco_master'];
 const choices=state.data?.skins||[];
 const picked=['karambit-doppler','awp-asiimov','ak-neon','ak-slate','deag-print','glock-neo','m4a-print','m4-neo','ak-redline','butterfly-fade','awp-dragon','usp-kill','m4a-lotus','ak-empress','sport-vice'];
 return Array.from({length:25},(_,i)=>{
  const id=picked[(i*7+5)%picked.length],s=skin(id)||choices[(i*9)%choices.length];
  return {name:names[(i*5+3)%names.length],skinName:s?.name||'AK-47 | Redline',skinId:s?.id,rarity:s?.rarity||'blue',image:s?.image||'',demo:true};
 });
}
function tickerPill(d){
 const color=rarity(d.rarity).color;
 return `<div class="drop-pill" style="--tier:${color}">${imageTag(d.image||skin(d.skinId)?.image,'','weapon',d.skinName)}<span class="drop-pill-info"><b>${esc(d.skinName)}</b><small>${esc(d.name||d.display_name)} ${d.demo?'· бот':'· игрок'}</small></span></div>`;
}
function renderFeed(){
 const real=(state.data?.recent||[]).slice(0,15).map(d=>({...d,name:d.display_name,demo:false}));
 const demo=demoFeed();
 const mixed=demo.slice();for(let i=0;i<Math.min(real.length,10);i++)mixed.splice(i*3,0,real[i]);
 const html=mixed.map(tickerPill).join('');
 $('#ticker-track').innerHTML=html+html;
}
function sectionHeading(title,subtitle='',link=null){return `<div class="section-heading"><div class="section-title-wrap"><span class="heading-stroke"></span><div><h2 class="section-title">${esc(title)}</h2>${subtitle?`<div class="section-caption">${esc(subtitle)}</div>`:''}</div></div>${link?`<button class="heading-link" data-action="navigate" data-view="${esc(link[1])}">${esc(link[0])} <span>→</span></button>`:''}</div>`;}
function caseCard(c,i){
 return `<button class="case-card" data-action="open-case-page" data-case="${esc(c.id)}" style="--glow:${esc(c.theme)}"><div class="case-card-top"><span class="case-overline">DROP #${String(i+1).padStart(3,'0')}</span>${c.tag?`<span class="case-tag">${esc(c.tag)}</span>`:''}</div><div class="case-visual"><span class="case-glyph">${esc(c.glyph)}</span>${caseCover(c)}${state.user?.favoriteCase===c.id?'<span class="case-fave">★ ИЗБРАННЫЙ</span>':''}</div><div class="case-bottom"><div class="case-name">${esc(c.name)}</div><div class="case-subtitle">${esc(c.subtitle)}</div><div class="case-footer"><span class="case-cost">${fmt(c.price)} <small>CR</small></span><span class="case-open">↗</span></div></div></button>`;
}
function hero(){const art=skin('ak-neon')||skin('m4a-print');return `<section class="hero"><div class="hero-copy"><div class="eyebrow">СКИНЫ. КЕЙСЫ. АДРЕНАЛИН.</div><h1>ТВОЙ ДРОП.<br><em>ТВОИ ПРАВИЛА.</em></h1><p>Открывай культовые кейсы, выбивай легендарные скины CS2 и собирай свою коллекцию. Без вложений, но с настоящими шансами симулятора. Дорогие дропы редки.</p><div class="hero-actions"><button class="btn btn-primary" data-action="navigate" data-view="cases">◈ &nbsp; КРУТИТЬ КЕЙСЫ <span>↗</span></button><button class="btn btn-ghost" data-action="navigate" data-view="faq">Как это работает <span>→</span></button></div></div><div class="hero-art"><div class="hero-orbit"></div><span class="hero-spark hero-spark-a">✦</span><span class="hero-spark hero-spark-b">✧</span>${skinArt(art,'hero-weapon '+(!art?.image?'placeholder':''))}<span class="hero-index">001 / SIMULATION</span><span class="hero-label">★ RARE DROP ZONE</span></div></section>`;}
function stats(){const d=state.data;return `<div class="stats-strip"><div class="stat"><span class="stat-icon">◈</span><div><div class="stat-num">${fmt(d.cases.length)}</div><div class="stat-label">Авторских кейсов</div></div></div><div class="stat"><span class="stat-icon">✧</span><div><div class="stat-num">${fmt(d.skins.length)}</div><div class="stat-label">Скинов CS2 в пуле</div></div></div><div class="stat"><span class="stat-icon">↗</span><div><div class="stat-num">${fmt(d.totals?.opens||0)}</div><div class="stat-label">Реальных открытий на сайте</div></div></div><div class="stat"><span class="stat-icon">◎</span><div><div class="stat-num">100%</div><div class="stat-label">Бесплатная симуляция</div></div></div></div>`;}
function renderHome(){const cases=state.data.cases;return `${hero()}${sectionHeading('Горячие кейсы','Авторские кейсы с редкими выпадениями',['ПОКАЗАТЬ ВСЕ','cases'])}<div class="cases-grid">${[cases[0],cases[1],cases[12],cases[13],cases[14],cases[15],cases[16],cases[2],cases[4],cases[6]].filter(Boolean).map((c,i)=>caseCard(c,i)).join('')}</div><div class="promo-row"><div class="promo"><div class="promo-text"><span class="promo-kicker">FREE TO PLAY</span><div class="promo-title">+200 CR КАЖДЫЙ ДЕНЬ</div><div class="promo-desc">Никаких депозитов. Заходи, получай, крути.</div></div><span class="promo-symbol">✦</span><button class="btn btn-primary" data-action="bonus">ЗАБРАТЬ ↗</button></div><div class="promo"><div class="promo-text"><span class="promo-kicker">YOUR LOADOUT</span><div class="promo-title">ТВОЯ КОЛЛЕКЦИЯ</div><div class="promo-desc">Сохраняй выпавшее или продавай за CR.</div></div><span class="promo-symbol">◈</span><button class="btn btn-ghost" data-action="navigate" data-view="inventory">ИНВЕНТАРЬ ↗</button></div></div>${sectionHeading('ЕЩЁ БОЛЬШЕ КЕЙСОВ','Любимые мемы и неоновые коллекции',['ВСЕ 40 КЕЙСОВ','cases'])}<div class="cases-grid">${cases.slice(17,27).map((c,i)=>caseCard(c,i+10)).join('')}</div>${stats()}`;}
function renderCases(){return `<div class="page-header"><div class="eyebrow">CASE COLLECTION / 2026</div><h1>КАТАЛОГ КЕЙСОВ</h1><p>От дешёвых эко-кейсов до охоты за редкими ножами. Выбирай свой риск — все награды и цены здесь виртуальные.</p></div><div class="section-category-tabs" id="case-filter"><button class="filter-tab active" data-action="filter-cases" data-filter="all">Все кейсы <span>(${state.data.cases.length})</span></button><button class="filter-tab" data-action="filter-cases" data-filter="budget">До 200 CR</button><button class="filter-tab" data-action="filter-cases" data-filter="premium">Премиум</button><button class="filter-tab" data-action="filter-cases" data-filter="meme">Мемные</button></div><div class="cases-grid" id="case-list">${state.data.cases.map(caseCard).join('')}</div>`;}
function applyCaseFilter(filter){
 const cases=state.data.cases;
 const result=cases.filter(c=>filter==='all'||filter==='budget'&&c.price<=200||filter==='premium'&&c.price>=690||filter==='meme'&&['67','chatgpt','godmode','matrix','hacker','chucky','lacra','ksante'].includes(c.id));
 $('#case-list').innerHTML=result.map(caseCard).join('');
 $$('#case-filter .filter-tab').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
}
function lootCard(s){return `<div class="loot-item" style="--tier:${esc(rarity(s.rarity).color)}"><div class="loot-item-img">${skinArt(s)}</div><div class="loot-name" title="${esc(s.name)}">${esc(s.name)}</div><div class="loot-rarity">${esc(rarity(s.rarity).name)}</div><div class="loot-bottom"><span class="loot-price">${fmt(s.price)} CR</span><span class="loot-chance">${(s.probability<.001?s.probability.toFixed(5):s.probability<.01?s.probability.toFixed(3):s.probability.toFixed(2))}%</span></div></div>`;}
async function renderCaseDetail(id){
 const c=getCase(id);if(!c){navigate('cases');return;}
 $('#view').innerHTML=`<div class="loading-wrap"><span class="load-spinner"></span><p>Готовим содержимое кейса...</p></div>`;
 let details;try{details=await api('/api/cases/'+encodeURIComponent(id));}catch(e){toast(e.message,true);navigate('cases');return;}
 if(state.view!=='case'||state.caseId!==id)return;
 const featured=skin({'67':'karambit-fade','chatgpt':'m4a-print','kilowatt':'ak-neon','revolution':'m4-temukau','knife':'karambit-doppler','nightcity':'ak-neon','dragon':'awp-dragon','eco':'ak-slate','printstream':'deag-print','gloves':'sport-vice','recoil':'ak-redline','godmode':'m4-howl'}[id]);
 const pic=c.coverImage?imageTag(c.coverImage,'stage-art','weapon',c.name):skinArt(featured,'stage-art');
 $('#view').innerHTML=`<div class="case-detail-top"><button class="back-btn" data-action="navigate" data-view="cases">← &nbsp; НАЗАД К КЕЙСАМ</button><span class="case-overline">CASE / ${esc(c.id.toUpperCase())}</span></div><div class="case-stage" style="--accent:${esc(c.theme)}"><div class="eyebrow">OPENING SESSION</div><h1>${esc(c.name)}</h1><div class="case-stage-sub">${esc(c.subtitle)} · ${details.items.length} ПРЕДМЕТОВ</div><div id="opening-zone">${pic}</div><div class="stage-cost">${fmt(c.price)} <small>CR / ОТКРЫТИЕ</small></div><div class="stage-actions" id="stage-actions"><button class="btn btn-primary" data-action="spin" data-case="${esc(c.id)}" id="open-case-btn">◈ &nbsp; ОТКРЫТЬ КЕЙС <span>↗</span></button><button class="btn btn-ghost" data-action="navigate" data-view="inventory">МОИ СКИНЫ</button></div><div class="stage-note">Обычные предметы: <b>${(details.odds.blue+details.odds.purple).toFixed(1)}%</b> · Средняя отдача: <b>${c.returnPct}%</b> цены · Без настоящих ставок</div></div>${sectionHeading('Содержимое кейса','Все шансы и игровые цены открыты. Средний возврат: '+fmt(c.expectedReturn)+' CR из '+fmt(c.price)+' CR')}<div class="loot-grid">${details.items.slice().sort((a,b)=>b.price-a.price).map(lootCard).join('')}</div>`;
}
function reelItem(s){return `<div class="reel-card" style="--tier:${esc(rarity(s?.rarity).color)}">${skinArt(s)}<span title="${esc(s?.name||'')}">${esc(s?.name||'Скин')}</span></div>`;}
async function spinCase(id){
 if(state.busy)return;
 if(!state.user){loginModal();return;}
 const c=getCase(id);if(!c)return;
 if(state.user.balance<c.price){toast('Недостаточно CR. Забери дневной бонус или продай скины.',true);return;}
 state.busy=true;
 const btn=$('#open-case-btn');if(btn)btn.disabled=true;
 let result;
 try{result=await api('/api/cases/open','POST',{caseId:id});}
 catch(e){state.busy=false;if(btn)btn.disabled=false;toast(e.message,true);return;}
 state.user.balance=result.balance;renderAccount();
 const zone=$('#opening-zone');if(!zone){state.busy=false;showResult(result);return;}
 zone.innerHTML=`<div class="reel-shell" id="reel-shell"><span class="reel-pointer"></span><div class="reel-track" id="reel-track">${result.reel.map(id=>reelItem(skin(id))).join('')}</div></div><div class="spin-status active"><span class="load-spinner" style="width:15px;height:15px;border-width:2px"></span> ОТКРЫВАЕМ КЕЙС...</div>`;
 const t=$('#reel-track'),shell=$('#reel-shell'),cardWidth=164;
 const target=-(result.hitIndex*cardWidth+77-shell.clientWidth/2)+(Math.random()-.5)*38;
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  t.style.transition='transform 5.8s cubic-bezier(.11,.78,.08,1)';
  t.style.transform=`translateX(${target}px)`;
 }));
 await new Promise(r=>setTimeout(r,6000));
 state.busy=false;state.latestDrop=result.item;
 if($('#open-case-btn'))$('#open-case-btn').disabled=false;
 showResult(result);
 try{const response=await api('/api/feed');state.data.recent=response.recent;renderFeed();}catch{}
}
function modal(html,extra=''){$('#modal-root').innerHTML=`<div class="modal-overlay" data-action="modal-overlay"><div class="modal ${extra}" role="dialog" aria-modal="true">${html}</div></div>`;document.body.style.overflow='hidden';}
function closeModal(){if(state.busy)return;$('#modal-root').innerHTML='';document.body.style.overflow='';}
function loginModal(admin=false){
 if(admin){modal(`<button class="modal-close" data-action="close-modal" aria-label="Закрыть">×</button><div class="modal-eyebrow">SECURE AREA / ACCESS</div><h2>АДМИН-ПАНЕЛЬ</h2><p>Для входа используй логин и пароль из переменных сервера. SteamID администратора также можно указать через ADMIN_STEAM_IDS.</p><form id="admin-login" class="login-fields"><div class="field"><label>Логин</label><input class="input" name="username" autocomplete="username" required /></div><div class="field"><label>Пароль</label><input class="input" name="password" type="password" autocomplete="current-password" required /></div><button class="btn btn-primary" type="submit">ВОЙТИ КАК АДМИН ↗</button></form><button class="text-link" data-action="show-login">Назад к обычному входу</button>`);return;}
 modal(`<button class="modal-close" data-action="close-modal" aria-label="Закрыть">×</button><div class="modal-eyebrow">WELCOME TO DROPLAB</div><h2>ЗАЛЕТАЙ В ИГРУ.</h2><p>Войди через официальный Steam или попробуй симулятор гостем. Стартовый баланс — <b style="color:#c9ff50">1 500 CR</b>.</p><div class="modal-choices"><a class="steam-btn" href="/auth/steam"><span class="steam-icon">◉</span> ВОЙТИ ЧЕРЕЗ STEAM <span>↗</span></a><div class="modal-separator">ИЛИ</div><button class="btn btn-primary" data-action="guest-login">ПРОДОЛЖИТЬ КАК ГОСТЬ ↗</button></div><p class="modal-footnote">Пароль Steam вводится только на сайте Steam. Скины нельзя перевести в Steam или вывести за деньги.</p><button class="text-link" data-action="show-admin-login">Вход для администратора</button>`);
}
function showResult(result){
 const item=result.item;const r=rarity(item.rarity);
 modal(`<button class="modal-close" data-action="close-modal" aria-label="Закрыть">×</button><div class="modal-eyebrow">CASE OPENED / NEW DROP</div><h2>ТВОЙ ДРОП!</h2>${skinArt(item,'result-image')}<div class="rarity-label" style="--drop-color:${esc(r.color)}">${esc(r.name)}</div><div class="result-name">${esc(item.name)}</div><div class="result-subtitle">Состояние: ${esc(item.wear)}</div><div class="result-price">${fmt(item.price)} <small>CR</small></div><div class="result-buttons"><button class="btn btn-primary" data-action="result-sell" data-item="${item.inventoryId}">ПРОДАТЬ ЗА ${fmt(item.price)} CR</button><button class="btn btn-ghost" data-action="close-modal">ОСТАВИТЬ</button></div><p class="modal-footnote">Предмет добавлен в твой инвентарь. Цена и предмет виртуальные.</p>`, 'result-modal');
 $('.result-modal').style.setProperty('--drop-color',r.color);
}
async function guestLogin(){try{const r=await api('/api/auth/guest','POST');state.user=r.user;await bootstrap(false);closeModal();toast('Аккаунт создан! +1 500 CR на балансе.');}catch(e){toast(e.message,true);}}
async function adminLogin(event){event.preventDefault();const f=new FormData(event.target);try{const r=await api('/api/auth/admin','POST',{username:f.get('username'),password:f.get('password')});state.user=r.user;await bootstrap(false);closeModal();navigate('admin');toast('Вход администратора выполнен.');}catch(e){toast(e.message,true);}}
async function doLogout(){try{await api('/api/auth/logout','POST');state.user=null;state.csrf=null;await bootstrap(false);navigate('home');toast('Вы вышли из аккаунта.');}catch(e){toast(e.message,true);}}
async function bonus(){if(!state.user){loginModal();return;}try{const r=await api('/api/bonus/claim','POST');state.user.balance=r.balance;state.user.lastBonus=Date.now();renderAccount();toast('+200 CR! Ежедневный бонус получен.');}catch(e){toast(e.message,true);}}
async function renderInventory(){
 if(!state.user){$('#view').innerHTML=`<div class="page-header"><div class="eyebrow">PERSONAL STORAGE</div><h1>МОЙ ИНВЕНТАРЬ</h1></div>${emptyState('▤','Войди, чтобы собирать скины','Все открытые предметы автоматически сохраняются в твоём аккаунте.','ВОЙТИ', 'account')}`;return;}
 $('#view').innerHTML='<div class="loading-wrap"><span class="load-spinner"></span></div>';
 try{state.profile=await api('/api/profile');}catch(e){toast(e.message,true);return;}
 if(state.view!=='inventory')return;
 const p=state.profile,avatar=state.user.avatar?`<img src="${url(state.user.avatar)}" alt="">`:esc(state.user.name[0]);
 $('#view').innerHTML=`<div class="page-header"><div class="eyebrow">YOUR ACCOUNT / LOADOUT</div><h1>МОЙ ИНВЕНТАРЬ</h1><p>Твоя коллекция: сохраняй скины, продавай за CR или отправляй в апгрейдер.</p></div><div class="profile-bar"><div class="profile-person"><span class="big-avatar">${avatar}</span><div><h1>${esc(state.user.name)}</h1><p>${state.user.steamId?'Steam ID: '+esc(state.user.steamId):state.user.role==='admin'?'Администратор':'Гостевой профиль'} · предметы сохраняются на сервере</p></div></div><div class="profile-metrics"><div class="profile-metric"><small>БАЛАНС</small><b>${fmt(state.user.balance)} CR</b></div><div class="profile-metric"><small>ОТКРЫТО КЕЙСОВ</small><b>${fmt(p.stats.openings)}</b></div><div class="profile-metric"><small>ЦЕННОСТЬ СКИНОВ</small><b>${fmt(p.stats.inventoryValue)} CR</b></div></div></div><div class="profile-extras"><div class="profile-extra"><span>★ ЛЮБИМЫЙ КЕЙС</span><div class="profile-fav-content">${state.user.favoriteCase?caseCover(getCase(state.user.favoriteCase)||state.data.cases[0]):'<span class="profile-star">✦</span>'}<div><b>${esc(getCase(state.user.favoriteCase)?.name||'Не выбран')}</b><small>Выбери кейс, чтобы закрепить его в профиле</small></div></div><div class="profile-fav-controls"><select class="input" id="favorite-case" aria-label="Любимый кейс"><option value="">— Выбери любимый —</option>${state.data.cases.map(c=>`<option value="${esc(c.id)}" ${c.id===state.user.favoriteCase?'selected':''}>${esc(c.name)}</option>`).join('')}</select><button class="btn btn-primary" data-action="save-favorite">СОХРАНИТЬ ★</button></div></div><div class="profile-extra"><span>◈ СТАТИСТИКА ПРОФИЛЯ</span><div class="profile-extra-stats"><div><strong>${fmt(p.stats.upgrades)}</strong><small>Попыток апгрейда</small></div><div><strong>${fmt(p.stats.upgradeWins)}</strong><small>Успешных</small></div><div><strong>${fmt(p.stats.items)}</strong><small>В коллекции</small></div></div><button class="btn btn-ghost" data-action="navigate" data-view="upgrade">ПЕРЕЙТИ В АПГРЕЙДЕР ↗</button></div><div class="profile-extra"><span>✦ ЛУЧШИЙ ДРОП</span>${p.stats.bestDrop?`<div class="profile-best">${skinArt(skin(p.stats.bestDrop.skin_id))}<div><b>${esc(p.stats.bestDrop.skin_name)}</b><small>${fmt(p.stats.bestDrop.price)} CR</small></div></div>`:'<p class="profile-empty-best">Открывай кейсы, чтобы поставить рекорд</p>'}</div></div>${sectionHeading('Моя коллекция',p.stats.items+' предметов в инвентаре')}<div class="inventory-actions"><div class="section-category-tabs" id="inventory-filters" style="margin:0"><button class="filter-tab active" data-action="inv-filter" data-filter="all">Все</button><button class="filter-tab" data-action="inv-filter" data-filter="gold">Особые</button><button class="filter-tab" data-action="inv-filter" data-filter="red">Тайные</button><button class="filter-tab" data-action="inv-filter" data-filter="pink">Засекреченные</button></div><div style="display:flex;gap:8px"><select class="input" id="inventory-sort" aria-label="Сортировка" style="min-height:37px;font-size:11px"><option value="new">Сначала новые</option><option value="price">Самые дорогие</option></select>${p.inventory.length?'<button class="btn btn-dark" data-action="sell-all">ПРОДАТЬ ВСЁ ↗</button>':''}</div></div><div id="inventory-list"></div>`;
 $('#inventory-sort').value=state.sort;renderInventoryGrid();
}
function emptyState(icon,title,sub,button,action){return `<div class="empty-state"><div class="empty-icon">${esc(icon)}</div><h3>${esc(title)}</h3><p>${esc(sub)}</p><button class="btn btn-primary" data-action="${esc(action)}">${esc(button)} ↗</button></div>`;}
function renderInventoryGrid(){
 const list=$('#inventory-list');if(!list)return;
 let items=(state.profile?.inventory||[]).filter(i=>state.filter==='all'||i.rarity===state.filter);
 if(state.sort==='price')items=items.slice().sort((a,b)=>b.price-a.price);
 if(!items.length){list.innerHTML=emptyState('◇','Тут пока пусто','Открой первый кейс и начинай собирать коллекцию.','КРУТИТЬ КЕЙСЫ','go-cases');return;}
 list.innerHTML=`<div class="inventory-grid">${items.map(i=>`<div class="inventory-card" style="--tier:${esc(rarity(i.rarity).color)}"><div class="loot-item-img">${skinArt({id:i.skinId,name:i.skinName,image:i.image})}</div><div class="inv-meta"><h3 title="${esc(i.skinName)}">${esc(i.skinName)}</h3><p>${esc(rarity(i.rarity).name)} · ${esc(i.wear)}</p><div class="inv-footer"><span class="inv-price">${fmt(i.price)} CR</span><button class="sell-btn" data-action="sell-item" data-item="${i.id}">ПРОДАТЬ</button></div><button class="to-upgrade" data-action="use-upgrade" data-item="${i.id}">⚡ УЛУЧШИТЬ В АПГРЕЙДЕРЕ</button></div></div>`).join('')}</div>`;
}
async function sellItem(id,fromResult=false){try{const r=await api('/api/inventory/'+encodeURIComponent(id)+'/sell','POST');state.user.balance=r.balance;renderAccount();if(fromResult)closeModal();if(state.view==='inventory')await renderInventory();toast('Предмет продан. +'+fmt(r.earned)+' CR');}catch(e){toast(e.message,true);}}
async function sellAll(){if(!state.profile?.inventory?.length)return;if(!confirm('Продать все скины за виртуальные кредиты? Это действие нельзя отменить.'))return;try{const r=await api('/api/inventory/sell-all','POST');state.user.balance=r.balance;renderAccount();await renderInventory();toast('Продано '+r.count+' предметов. +'+fmt(r.earned)+' CR');}catch(e){toast(e.message,true);}}
const chanceFor=(source,target)=>source&&target?Math.max(.001,Math.min(75,Math.round(source.price/target.price*85*1000)/1000)):0;
const displayChance=ch=>ch<1?ch.toFixed(3).replace(/0+$/,'').replace(/\.$/,''):ch.toFixed(2);
async function renderUpgrade(){
 if(!state.user){$('#view').innerHTML=`<div class="page-header"><div class="eyebrow">SKIN UPGRADE / SIMULATOR</div><h1>АПГРЕЙДЕР СКИНОВ</h1></div>${emptyState('⚡','Для апгрейда нужен инвентарь','Войди и выбей первый скин, затем попробуй получить скин дороже.','ВОЙТИ','account')}`;return;}
 $('#view').innerHTML='<div class="loading-wrap"><span class="load-spinner"></span><p>Собираем твои скины...</p></div>';
 try{state.profile=await api('/api/profile');}catch(e){toast(e.message,true);return;}
 if(state.view!=='upgrade')return;
 const inv=state.profile.inventory;
 if(!inv.some(s=>s.id===state.upgradeSource))state.upgradeSource=inv[0]?.id||null;
 const source=inv.find(s=>s.id===state.upgradeSource);
 if(source&&(!skin(state.upgradeTarget)||skin(state.upgradeTarget).price<=source.price)){
   state.upgradeTarget=state.data.skins.filter(s=>s.price>source.price).sort((a,b)=>Math.abs(a.price-source.price*2.7)-Math.abs(b.price-source.price*2.7))[0]?.id||null;
 }
 renderUpgradeUI();
}
function upgradeItemCard(s,kind){
 const isSource=kind==='source';const chosen=isSource?state.upgradeSource===s.id:state.upgradeTarget===s.id;
 return `<button class="upgrade-mini ${chosen?'selected':''}" style="--tier:${esc(rarity(s.rarity).color)}" data-action="upgrade-${kind}" data-${isSource?'item':'skin'}="${esc(s.id)}">${skinArt({id:s.skinId||s.id,name:s.skinName||s.name,image:s.image})}<span title="${esc(s.skinName||s.name)}">${esc(s.skinName||s.name)}</span><b>${fmt(s.price)} CR</b></button>`;
}
function renderUpgradeUI(){
 const inventory=state.profile?.inventory||[];
 const source=inventory.find(s=>s.id===state.upgradeSource);
 const target=skin(state.upgradeTarget);
 const all=state.data.skins.filter(s=>source&&s.price>source.price);
 const filtered=all.filter(s=>{
  const k=s.price/source.price;
  const range=state.upgradeRange;
  if(range==='2x'&&(k<1||k>2.5))return false;
  if(range==='5x'&&(k<2.5||k>5))return false;
  if(range==='10x'&&(k<5||k>10))return false;
  if(range==='max'&&k<10)return false;
  return !state.upgradeSearch||s.name.toLowerCase().includes(state.upgradeSearch.toLowerCase());
 }).sort((a,b)=>a.price-b.price);
 const ch=chanceFor(source,target), winAngle=(ch/100*360).toFixed(4);
 const sourceMarkup=source?`<div class="upgrade-selected-skin">${skinArt({id:source.skinId,name:source.skinName,image:source.image})}<div><span>ТВОЙ ПРЕДМЕТ</span><b>${esc(source.skinName)}</b><strong>${fmt(source.price)} CR</strong></div></div>`:'<div class="upgrade-placeholder">Выбери скин из инвентаря ниже</div>';
 const targetMarkup=target?`<div class="upgrade-selected-skin">${skinArt(target)}<div><span>ЦЕЛЕВОЙ СКИН</span><b>${esc(target.name)}</b><strong>${fmt(target.price)} CR</strong></div></div>`:'<div class="upgrade-placeholder">Выбери целевой скин ниже</div>';
 $('#view').innerHTML=`<div class="page-header upgrade-heading"><div class="eyebrow">UPGRADE LAB / LIVE SIMULATION</div><h1>АПГРЕЙДЕР <em>СКИНОВ</em></h1><p>Выбери свой скин и более дорогую цель. Результат честно рассчитывается на сервере, а выбор анимации на шанс не влияет.</p></div>
 <div class="upgrade-console"><div class="upgrade-display"><div class="upgrade-side"><div class="upgrade-small-label">01 / ОТДАЁШЬ</div>${sourceMarkup}</div>
 <div class="upgrade-center"><div class="upgrade-wheel" id="upgrade-wheel" style="--win-angle:${winAngle}deg"><div class="upgrade-ticks"></div><div class="upgrade-needle" id="upgrade-needle"><div class="upgrade-needle-tip"></div></div><div class="upgrade-wheel-center"><small>ШАНС УСПЕХА</small><strong id="upgrade-chance">${source&&target?displayChance(ch)+'%':'—'}</strong><span>UPGRADE LAB</span></div></div><div class="upgrade-legend"><span><i class="legend-win"></i> УСПЕХ</span><span><i class="legend-lose"></i> НЕУДАЧА</span></div></div>
 <div class="upgrade-side"><div class="upgrade-small-label">02 / ПОЛУЧАЕШЬ ПРИ УСПЕХЕ</div>${targetMarkup}</div></div>
 <div class="upgrade-console-bottom"><div class="motion-control"><span>АНИМАЦИЯ СТРЕЛКИ</span><div class="motion-tabs"><button class="${state.upgradeMotion==='normal'?'active':''}" data-action="upgrade-motion" data-motion="normal">◉ ОБЫЧНАЯ <small>3,4 сек · ровная остановка</small></button><button class="${state.upgradeMotion==='thrill'?'active':''}" data-action="upgrade-motion" data-motion="thrill">⚡ АЗАРТНАЯ <small>8 сек · долгий докрут и откат</small></button></div></div><div class="upgrade-action"><div class="upgrade-ev">Расчётная отдача: <b>85%</b> стоимости исходного скина</div><button id="upgrade-start-btn" class="btn btn-primary" data-action="upgrade-start" ${source&&target?'':'disabled'}>⚡ НАЧАТЬ АПГРЕЙД ↗</button><small>Без реальных денег, обмена и вывода. При проигрыше исходный скин теряется.</small></div></div></div>
 <div class="upgrade-picker-grid"><div class="upgrade-pick"><div class="upgrade-pick-title"><div><span>01 / SOURCE</span><h2>ТВОИ СКИНЫ <small>${inventory.length}</small></h2></div><button class="text-link" data-action="navigate" data-view="inventory">ИНВЕНТАРЬ ↗</button></div>${inventory.length?`<div class="upgrade-items">${inventory.map(s=>upgradeItemCard({...s,id:s.id},'source')).join('')}</div>`:emptyState('▤','Инвентарь пуст','Открой кейс, чтобы получить первый предмет.','К КЕЙСАМ','go-cases')}</div>
 <div class="upgrade-pick"><div class="upgrade-pick-title"><div><span>02 / TARGET</span><h2>ВЫБЕРИ ЦЕЛЬ <small>${filtered.length}</small></h2></div></div><div class="upgrade-picker-tools"><select class="input" id="upgrade-range"><option value="all">Любая цена</option><option value="2x">До ×2.5</option><option value="5x">×2.5 – ×5</option><option value="10x">×5 – ×10</option><option value="max">×10 и выше</option></select><input class="input" id="upgrade-search" value="${esc(state.upgradeSearch)}" placeholder="Поиск скина..."/></div><div class="upgrade-items" id="upgrade-target-list">${source?(filtered.length?filtered.slice(0,72).map(s=>upgradeItemCard(s,'target')).join(''):'<div class="upgrade-nothing">Нет скинов в этом диапазоне</div>'):'<div class="upgrade-nothing">Сначала выбери свой скин</div>'}</div><small class="upgrade-target-note">Показаны первые 72 предмета выбранного диапазона · цены игровые</small></div></div>`;
 const sel=$('#upgrade-range');if(sel)sel.value=state.upgradeRange;
}
async function performUpgrade(){
 if(state.busy)return;
 const source=state.profile?.inventory?.find(s=>s.id===state.upgradeSource),target=skin(state.upgradeTarget);
 if(!source||!target){toast('Выбери оба скина',true);return;}
 state.busy=true;const btn=$('#upgrade-start-btn');btn.disabled=true;btn.textContent='СТРЕЛКА КРУТИТСЯ...';
 let result;
 try{result=await api('/api/upgrade/attempt','POST',{inventoryId:source.id,targetSkinId:target.id});}
 catch(e){state.busy=false;btn.disabled=false;btn.textContent='⚡ НАЧАТЬ АПГРЕЙД ↗';toast(e.message,true);return;}
 const wheel=$('#upgrade-wheel'),needle=$('#upgrade-needle');
 const boundary=result.chance*3.6;
 const aim=result.success?boundary*(.2+Math.random()*.6):boundary+(360-boundary)*(.03+Math.random()*.94);
 const end=7*360+aim;
 const thrill=state.upgradeMotion==='thrill',duration=thrill?8000:3400;
 const frames=thrill?[
   {transform:'rotate(0deg)',offset:0,easing:'cubic-bezier(.35,.05,.65,.95)'},
   {transform:`rotate(${end-315}deg)`,offset:.71,easing:'cubic-bezier(.05,.5,.13,1)'},
   {transform:`rotate(${end+19}deg)`,offset:.91,easing:'ease-out'},
   {transform:`rotate(${end-8}deg)`,offset:.968,easing:'ease-in-out'},
   {transform:`rotate(${end}deg)`,offset:1}
 ]:[{transform:'rotate(0deg)'},{transform:`rotate(${end}deg)`}];
 if(needle?.animate){
  const animation=needle.animate(frames,{duration,easing:thrill?'linear':'cubic-bezier(.09,.68,.12,1)',fill:'forwards'});
  try{await animation.finished;}catch{}
 }else{needle.style.transition=`transform ${duration}ms cubic-bezier(.09,.68,.12,1)`;requestAnimationFrame(()=>{needle.style.transform=`rotate(${end}deg)`;});await new Promise(r=>setTimeout(r,duration));}
 wheel?.classList.add(result.success?'upgrade-win':'upgrade-lose');
 await new Promise(r=>setTimeout(r,430));
 state.busy=false;
 modal(`<button class="modal-close" data-action="close-modal" aria-label="Закрыть">×</button><div class="modal-eyebrow">UPGRADE / ${result.success?'SUCCESS':'FAILED'}</div><div class="upgrade-result-symbol">${result.success?'✦':'✕'}</div><h2>${result.success?'АПГРЕЙД УДАЛСЯ!':'АПГРЕЙД НЕ УДАЛСЯ'}</h2>${result.success?skinArt(result.item,'result-image'):''}<p>${result.success?`Ты получил <b>${esc(result.target.name)}</b> за ${fmt(result.target.price)} CR.`:`Предмет <b>${esc(result.source.name)}</b> использован. Целевой скин не получен.`}</p><div class="rarity-label">Шанс попытки: ${displayChance(result.chance)}%</div><div class="result-buttons"><button class="btn btn-primary" data-action="navigate-after-upgrade" data-view="upgrade">ЕЩЁ ПОПЫТКА ↗</button><button class="btn btn-ghost" data-action="navigate-after-upgrade" data-view="inventory">МОЙ ПРОФИЛЬ</button></div><p class="modal-footnote">Виртуальная симуляция. Режим вращения не меняет вероятность.</p>`,result.success?'result-modal upgrade-result-success':'result-modal');
 try{const response=await api('/api/feed');state.data.recent=response.recent;renderFeed();}catch{}
}
async function saveFavorite(){
 if(!state.user)return;
 try{const r=await api('/api/profile/favorite','POST',{caseId:$('#favorite-case')?.value||''});state.user.favoriteCase=r.favoriteCase;toast('Любимый кейс сохранён ★');await renderInventory();}
 catch(e){toast(e.message,true);}
}
async function renderLeaders(){
 $('#view').innerHTML=`<div class="page-header"><div class="eyebrow">HALL OF FAME</div><h1>ТОП ИГРОКОВ</h1><p>Рейтинг настоящих аккаунтов симулятора по количеству виртуальных кредитов. Демо-боты в рейтинг не попадают.</p></div><div class="loading-wrap"><span class="load-spinner"></span></div>`;
 try{state.leaderboard=(await api('/api/leaderboard')).players;}catch(e){toast(e.message,true);return;}
 if(state.view!=='leaders')return;
 const players=state.leaderboard;
 $('#view').innerHTML=`<div class="page-header"><div class="eyebrow">HALL OF FAME</div><h1>ТОП ИГРОКОВ</h1><p>Рейтинг настоящих аккаунтов симулятора по количеству виртуальных кредитов. Демо-боты в рейтинг не попадают.</p></div>${players.length?`<div class="leader-grid">${players.slice(0,3).map((p,i)=>`<div class="leader-card"><div class="leader-rank">#0${i+1}</div><h3>${esc(p.name)}</h3><p>${fmt(p.balance)} CR</p><small>Баланс игрока</small></div>`).join('')}</div><div class="leader-table">${players.slice(3).map((p,i)=>`<div class="leader-row"><b>#${i+4}</b><span>${esc(p.name)}</span><strong>${fmt(p.balance)} CR</strong></div>`).join('')}</div>`:emptyState('♛','Стань первым','Сейчас в таблице нет игроков. Открывай кейсы и попади в рейтинг.','ОТКРЫТЬ КЕЙСЫ','go-cases')}`;
}
function renderFaq(){return `<div class="page-header"><div class="eyebrow">HOW IT WORKS</div><h1>КАК ИГРАТЬ?</h1><p>Мы сделали коллекционный CS2-симулятор без реальных ставок, платежей и выводов.</p></div><div class="faq-grid"><div class="faq-card"><h3>01 / СОЗДАЙ АККАУНТ</h3><p>Войди через официальный Steam OpenID или выбери гостевой режим. На старте ты получишь 1 500 виртуальных кредитов (CR).</p></div><div class="faq-card"><h3>02 / ОТКРЫВАЙ КЕЙСЫ</h3><p>Выбери понравившийся кейс. За каждое открытие списывается игровая цена, а награда выбирается на сервере по указанным вероятностям.</p></div><div class="faq-card"><h3>03 / СОБИРАЙ И ПРОДАВАЙ</h3><p>Скин появляется в твоём инвентаре. Его можно оставить в коллекции или продать за игровые CR, чтобы открыть новые кейсы.</p></div><div class="faq-card"><h3>04 / ПОЛУЧАЙ БОНУС</h3><p>Раз в 24 часа забирай бесплатные +200 CR в меню слева. Никаких пополнений или платных функций нет.</p></div><div class="faq-card"><h3>ЭТО НАСТОЯЩИЕ СКИНЫ?</h3><p>Названия и картинки взяты из CS2, но выигранные вещи существуют только в DROPLAB. Они не поступают в Steam и не имеют денежной стоимости.</p></div><div class="faq-card"><h3>ЧТО ЗА ЛЕНТА LIVE DROPS?</h3><p>Лента вверху показывает игровые тестовые выпадения ботов, прямо помеченные как демо, и реальные открытия пользователей симулятора. Число активности также демонстрационное.</p></div><div class="faq-card"><h3>БЕЗОПАСЕН ЛИ ВХОД ЧЕРЕЗ STEAM?</h3><p>Кнопка отправляет тебя на steamcommunity.com по официальному OpenID. Мы не запрашиваем и не сохраняем пароль Steam. Чтобы работали профили и аватары Steam, администратор может настроить ключ Steam Web API.</p></div><div class="faq-card"><h3>САЙТ ОФИЦИАЛЬНЫЙ?</h3><p>Нет. DROPLAB — независимый фанатский проект-симулятор, не связанный с Valve или Steam. Скины, названия и изображения принадлежат владельцам прав.</p></div></div>`;}
async function loadAdmin(q=''){
 try{const [users,logs]=await Promise.all([api('/api/admin/users?q='+encodeURIComponent(q)),api('/api/admin/logs')]);state.adminUsers=users.users;state.adminLogs=logs.logs;}catch(e){toast(e.message,true);}
 if(state.view==='admin')updateAdminTable();
}
function renderAdmin(){
 if(state.user?.role!=='admin'){navigate('home');return;}
 $('#view').innerHTML=`<div class="page-header"><div class="eyebrow">SERVER CONTROL / ADMIN ONLY</div><h1>АДМИН-ПАНЕЛЬ</h1><p>Баланс игроков изменяется в серверной базе данных. Выдача предметов и изменение кредитов доступно только подтверждённому администратору.</p></div><div class="admin-info">⚙ &nbsp; Админ-панель: управление балансом, поиск по имени / ID / SteamID, журнал начислений. Данные не хранятся в браузере.</div>${sectionHeading('Изменить баланс игроку')}<form id="admin-balance-form" class="admin-controls"><div class="field"><label>ID ИГРОКА</label><input class="input" id="admin-target" name="userId" required placeholder="guest:... или steam:7656..." /></div><div class="field"><label>СУММА CR</label><input class="input" name="amount" type="number" step="1" required value="1000" /></div><div class="field"><label>ТИП ДЕЙСТВИЯ</label><select class="input" name="mode"><option value="add">Добавить</option><option value="set">Установить</option></select></div><button class="btn btn-primary" type="submit" style="align-self:end">СОХРАНИТЬ ↗</button></form>${sectionHeading('Игроки')}<div class="field" style="max-width:460px;margin-bottom:12px"><label>ПОИСК</label><input class="input" id="admin-search" placeholder="Имя, SteamID, ID аккаунта" /></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>ИГРОК</th><th>ID</th><th>ТИП</th><th>БАЛАНС</th><th>ДЕЙСТВИЕ</th></tr></thead><tbody id="admin-users"><tr><td colspan="5">Загрузка...</td></tr></tbody></table></div>${sectionHeading('История начислений')}<div id="admin-logs"></div>`;
 loadAdmin();
}
function updateAdminTable(){
 const body=$('#admin-users');if(!body)return;
 body.innerHTML=state.adminUsers.length?state.adminUsers.map(u=>`<tr><td><b>${esc(u.name)}</b></td><td title="${esc(u.id)}">${esc(u.id.length>34?u.id.slice(0,34)+'…':u.id)}</td><td>${esc(u.role==='admin'?'Админ':u.steamId?'Steam':'Гость')}</td><td><b>${fmt(u.balance)} CR</b></td><td><button class="mini-btn" data-action="admin-select" data-user="${esc(u.id)}">НАЧИСЛИТЬ +</button></td></tr>`).join(''):'<tr><td colspan="5">Игроки не найдены</td></tr>';
 const logs=$('#admin-logs');if(logs)logs.innerHTML=state.adminLogs.length?state.adminLogs.slice(0,15).map(l=>`<div class="admin-log">${new Date(l.created_at).toLocaleString('ru-RU')} · <b>${esc(l.target_id)}</b> · ${l.amount>=0?'+':''}${fmt(l.amount)} CR (${fmt(l.before_balance)} → ${fmt(l.after_balance)})</div>`).join(''):'<div class="admin-log">Начислений ещё не было</div>';
}
async function changeBalance(e){e.preventDefault();const f=new FormData(e.target);try{const r=await api('/api/admin/balance','POST',{userId:f.get('userId'),amount:Number(f.get('amount')),mode:f.get('mode')});toast('Баланс обновлён: '+fmt(r.balance)+' CR');await loadAdmin($('#admin-search')?.value||'');if(state.user.id===r.userId){state.user.balance=r.balance;renderAccount();}}catch(e){toast(e.message,true);}}
async function bootstrap(withNav=true){
 const data=await api('/api/bootstrap');state.data=data;state.user=data.user;state.csrf=data.csrf;renderAccount();renderFeed();
 if(withNav){let hash=location.hash.slice(1);let parts=hash.split('/');if(parts[0]==='case'&&getCase(parts[1]))navigate('case',parts[1],false);else navigate(['home','cases','inventory','upgrade','leaders','faq','admin'].includes(hash)?hash:'home',null,false);}
 else {const v=state.view; if(v==='inventory')await renderInventory();else if(v==='admin')renderAdmin();else if(v==='case')renderCaseDetail(state.caseId);else if(v==='upgrade')await renderUpgrade();else renderCurrent();}
}
function navigate(view,id=null,changeHash=true){
 if(state.busy)return;
 if(view==='admin'&&state.user?.role!=='admin'){loginModal(true);return;}
 state.view=view;state.caseId=id;state.filter='all';state.busy=false;
 if(changeHash)location.hash=view==='case'?'case/'+id:view;
 const names={home:'ГЛАВНАЯ',cases:'ВСЕ КЕЙСЫ',case:'ОТКРЫТИЕ КЕЙСА',inventory:'ИНВЕНТАРЬ',upgrade:'АПГРЕЙДЕР',leaders:'РЕЙТИНГ',faq:'КАК ИГРАТЬ',admin:'ПАНЕЛЬ АДМИНА'};
 $('#page-crumb').textContent=names[view]||'ГЛАВНАЯ';
 $$('#side-nav .nav-link').forEach(b=>b.classList.toggle('active',b.dataset.view===(view==='case'?'cases':view)));
 renderCurrent();window.scrollTo({top:0,behavior:'instant'});
}
function renderCurrent(){if(!state.data)return;
 if(state.view==='home')$('#view').innerHTML=renderHome();
 if(state.view==='cases')$('#view').innerHTML=renderCases();
 if(state.view==='case')renderCaseDetail(state.caseId);
 if(state.view==='inventory')renderInventory();
 if(state.view==='upgrade')renderUpgrade();
 if(state.view==='leaders')renderLeaders();
 if(state.view==='faq')$('#view').innerHTML=renderFaq();
 if(state.view==='admin')renderAdmin();
}
document.addEventListener('click',async e=>{
 const t=e.target.closest('[data-action]');if(!t){if(e.target.matches('.modal-overlay'))closeModal();return;}
 const a=t.dataset.action;
 if(t.matches('a')&&a==='navigate')e.preventDefault();
 if(a==='navigate')navigate(t.dataset.view);
 if(a==='open-case-page')navigate('case',t.dataset.case);
 if(a==='filter-cases')applyCaseFilter(t.dataset.filter);
 if(a==='spin')spinCase(t.dataset.case);
 if(a==='upgrade-source'){state.upgradeSource=Number(t.dataset.item);const source=state.profile?.inventory.find(s=>s.id===state.upgradeSource);if(source&&skin(state.upgradeTarget)?.price<=source.price)state.upgradeTarget=null;renderUpgradeUI();}
 if(a==='upgrade-target'){state.upgradeTarget=t.dataset.skin;renderUpgradeUI();}
 if(a==='upgrade-motion'){state.upgradeMotion=t.dataset.motion;renderUpgradeUI();}
 if(a==='upgrade-start')performUpgrade();
 if(a==='save-favorite')saveFavorite();
 if(a==='use-upgrade'){state.upgradeSource=Number(t.dataset.item);navigate('upgrade');}
 if(a==='navigate-after-upgrade'){closeModal();navigate(t.dataset.view);}
 if(a==='close-modal')closeModal();
 if(a==='modal-overlay'&&t===e.target)closeModal();
 if(a==='wallet')state.user?bonus():loginModal();
 if(a==='account')state.user?modal(`<button class="modal-close" data-action="close-modal">×</button><div class="modal-eyebrow">PROFILE / ACCOUNT</div><h2>${esc(state.user.name)}</h2><p>Баланс: <b style="color:#c9ff50">${fmt(state.user.balance)} CR</b><br>ID: ${esc(state.user.id)}<br>Тип: ${state.user.steamId?'Steam':'Гостевой аккаунт'}</p><div class="modal-choices"><button class="btn btn-primary" data-action="view-inventory">МОЙ ИНВЕНТАРЬ ↗</button><button class="btn btn-dark" data-action="logout">ВЫЙТИ ИЗ АККАУНТА</button></div>`):loginModal();
 if(a==='view-inventory'){closeModal();navigate('inventory');}
 if(a==='guest-login')guestLogin();
 if(a==='show-login')loginModal();
 if(a==='show-admin-login')loginModal(true);
 if(a==='logout'){closeModal();doLogout();}
 if(a==='bonus')bonus();
 if(a==='go-cases'){closeModal();navigate('cases');}
 if(a==='inv-filter'){state.filter=t.dataset.filter;$$('#inventory-filters .filter-tab').forEach(x=>x.classList.toggle('active',x.dataset.filter===state.filter));renderInventoryGrid();}
 if(a==='sell-item')sellItem(t.dataset.item);
 if(a==='sell-all')sellAll();
 if(a==='result-sell')sellItem(t.dataset.item,true);
 if(a==='admin-select'){const el=$('#admin-target');if(el){el.value=t.dataset.user;el.scrollIntoView({behavior:'smooth',block:'center'});el.focus();}}
});
document.addEventListener('submit',e=>{if(e.target.id==='admin-login')adminLogin(e);if(e.target.id==='admin-balance-form')changeBalance(e);});
document.addEventListener('change',e=>{if(e.target.id==='inventory-sort'){state.sort=e.target.value;renderInventoryGrid();}if(e.target.id==='upgrade-range'){state.upgradeRange=e.target.value;renderUpgradeUI();}});
let searchTimer;document.addEventListener('input',e=>{if(e.target.id==='admin-search'){clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadAdmin(e.target.value),250);}if(e.target.id==='upgrade-search'){state.upgradeSearch=e.target.value;const input=$('#upgrade-search');renderUpgradeUI();$('#upgrade-search')?.focus();$('#upgrade-search')?.setSelectionRange(input?.selectionStart||0,input?.selectionStart||0);}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!state.busy)closeModal();});
document.addEventListener('error',e=>{const img=e.target;if(img.tagName==='IMG'&&!img.dataset.fallback){img.dataset.fallback='1';img.src=/knife|bayonet|karambit/i.test(img.alt)?'/assets/knife.svg':'/assets/weapon.svg';}},true);
window.addEventListener('hashchange',()=>{const p=location.hash.slice(1).split('/');if(p[0]==='case'&&getCase(p[1])){if(state.view!=='case'||state.caseId!==p[1])navigate('case',p[1],false);}else if(['home','cases','inventory','upgrade','leaders','faq','admin'].includes(p[0])&&state.view!==p[0])navigate(p[0],null,false);});
const auth=new URL(location.href).searchParams.get('auth');if(auth){setTimeout(()=>toast('Steam не подтвердил вход. Попробуйте ещё раз.',true),900);history.replaceState(null,'',location.pathname+location.hash);}
bootstrap().then(()=>{
 let tries=0;const refresher=setInterval(async()=>{
  tries++;
  if(tries>4){clearInterval(refresher);return;}
  if(state.data?.skins?.filter(x=>x.image).length>40){clearInterval(refresher);return;}
  try{const fresh=await api('/api/bootstrap');const was=state.data.skins.filter(x=>x.image).length;const current=fresh.skins.filter(x=>x.image).length;
   if(current>was){state.data=fresh;renderFeed();if(['home','cases','case'].includes(state.view)&&!state.busy)renderCurrent();if(current>45)clearInterval(refresher);}}
  catch{}
 },7000);
}).catch(e=>{$('#view').innerHTML=`<div class="empty-state"><div class="empty-icon">⚠</div><h3>НЕТ СВЯЗИ С СЕРВЕРОМ</h3><p>${esc(e.message)}. Проверь, что сервер запущен командой npm start, и открой сайт через localhost.</p></div>`;});
setInterval(()=>{const count=1240+Math.floor(Math.random()*160);$('#online-count').textContent=fmt(count);},12000);
})();
