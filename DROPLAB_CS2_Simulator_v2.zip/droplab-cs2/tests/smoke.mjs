import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const dir=mkdtempSync(path.join(os.tmpdir(),'droplab-test-'));
const port=32000+Math.floor(Math.random()*20000);
const base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['server.js'],{cwd:process.cwd(),env:{...process.env,PORT:String(port),BASE_URL:base,DB_PATH:path.join(dir,'test.db'),ADMIN_USERNAME:'admin',ADMIN_PASSWORD:'Testing#StrongPassword2026'},stdio:['ignore','pipe','pipe']});
let logs='';child.stdout.on('data',d=>{logs+=d.toString()});child.stderr.on('data',d=>{logs+=d.toString()});
async function get(path,cookie){let r=await fetch(base+path,{headers:cookie?{cookie}:{}});return [r,await r.json()];}
async function post(path,data={},cookie='',csrf=''){
 const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json',...(cookie?{cookie}:{}),...(csrf?{'x-csrf-token':csrf}:{})},body:JSON.stringify(data)});
 return [r,await r.json()];
}
async function ready(){for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error(logs);try{const r=await fetch(base+'/api/bootstrap');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,75));}throw Error('Server not ready '+logs);}
test('case simulator smoke test (persistent server balances and inventory)',{timeout:20000},async()=>{
 try{
  await ready();
  let [r,bootstrap]=await get('/api/bootstrap');assert.equal(r.status,200);assert.equal(bootstrap.cases.length,40);assert.ok(bootstrap.skins.length>=250);assert.ok(bootstrap.cases.every(c=>c.returnPct<100));
  [r]=await post('/api/auth/guest');assert.equal(r.status,200);let cookie=r.headers.get('set-cookie').split(';')[0];
  [r,bootstrap]=await get('/api/bootstrap',cookie);const csrf=bootstrap.csrf,user=bootstrap.user;assert.equal(user.balance,1500);
  let opened;[r,opened]=await post('/api/cases/open',{caseId:'67'},cookie,csrf);assert.equal(r.status,200);assert.equal(opened.balance,1433);assert.ok(opened.item.inventoryId);
  let profile;[r,profile]=await get('/api/profile',cookie);assert.equal(r.status,200);assert.equal(profile.inventory.length,1);
  // Profile favorites persist for a user, as do upgrade attempts.
  [r]=await post('/api/profile/favorite',{caseId:'chatgpt'},cookie,csrf);assert.equal(r.status,200);
  assert.equal((await get('/api/bootstrap',cookie))[1].user.favoriteCase,'chatgpt');
  [r]=await post('/api/profile/favorite',{caseId:'unknown'},cookie,csrf);assert.equal(r.status,400);
  const targets=bootstrap.skins.filter(s=>s.price>opened.item.price).sort((a,b)=>a.price-b.price);
  assert.ok(targets.length>0);
  const [ur,upgrade]=await post('/api/upgrade/attempt',{inventoryId:opened.item.inventoryId,targetSkinId:targets[0].id},cookie,csrf);
  assert.equal(ur.status,200);assert.equal(typeof upgrade.success,'boolean');assert.ok(upgrade.chance>0&&upgrade.chance<=75);
  [r]=await post('/api/upgrade/attempt',{inventoryId:opened.item.inventoryId,targetSkinId:targets[0].id},cookie,csrf);assert.equal(r.status,404);
  [r,profile]=await get('/api/profile',cookie);assert.equal(profile.stats.upgrades,1);
  // Open a new case for selling test, keeping the original no-repeat guarantee.
  [r,opened]=await post('/api/cases/open',{caseId:'67'},cookie,csrf);assert.equal(r.status,200);
  let sold;[r,sold]=await post('/api/inventory/'+opened.item.inventoryId+'/sell',{},cookie,csrf);assert.equal(r.status,200);assert.equal(sold.balance,1366+opened.item.price);
  [r]=await post('/api/inventory/'+opened.item.inventoryId+'/sell',{},cookie,csrf);assert.equal(r.status,404);
  [r]=await post('/api/bonus/claim',{},cookie,'bad-csrf');assert.equal(r.status,403);
  [r]=await post('/api/bonus/claim',{},cookie,csrf);assert.equal(r.status,200);
  [r]=await post('/api/bonus/claim',{},cookie,csrf);assert.equal(r.status,400);
  [r]=await get('/api/admin/users',cookie);assert.equal(r.status,403);
  [r]=await post('/api/auth/admin',{username:'admin',password:'Testing#StrongPassword2026'});assert.equal(r.status,200);
  let adminCookie=r.headers.get('set-cookie').split(';')[0],adminCsrf=(await get('/api/bootstrap',adminCookie))[1].csrf;
  let adjusted;[r,adjusted]=await post('/api/admin/balance',{userId:user.id,amount:650,mode:'add'},adminCookie,adminCsrf);assert.equal(r.status,200);
  assert.equal((await get('/api/bootstrap',cookie))[1].user.balance,adjusted.balance);
 }finally{child.kill('SIGTERM');rmSync(dir,{recursive:true,force:true});}
});
